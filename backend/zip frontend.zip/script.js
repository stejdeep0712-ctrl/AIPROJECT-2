
const API_BASE = "http://127.0.0.1:8000";

const API = {
    health: `${API_BASE}/health`,
    connection: `${API_BASE}/connection-assessment`,
    ai: `${API_BASE}/ai-advisory`,
    pq: `${API_BASE}/pq-screening`,
    pqInfo: `${API_BASE}/pq-model-info`,
    hosting: `${API_BASE}/hosting-results`
};

// =============================================
// HELPER FUNCTIONS
// =============================================

function getValue(id) {
    const element = document.getElementById(id);
    return element ? element.value.trim() : "";
}

function showNumber(value, digits = 2) {
    const number = Number(value);

    return Number.isFinite(number)
        ? number.toFixed(digits)
        : "Unavailable";
}

async function postJSON(url, payload) {
    try {
        const response = await fetch(url, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(payload)
        });

        const text = await response.text();

        let data;

        try {
            data = text ? JSON.parse(text) : {};
        } catch {
            throw new Error("Backend returned an invalid response.");
        }

        if (!response.ok) {
            throw new Error(
                data.detail || `Request failed (${response.status})`
            );
        }

        return data;

    } catch (error) {
        console.error("API request failed:", error);
        throw error;
    }
}

function setText(id, value) {
    const element = document.getElementById(id);

    if (element) {
        element.textContent = value ?? "Unavailable";
    }
}

function fillList(id, items) {
    const list = document.getElementById(id);

    if (!list) return;

    list.replaceChildren();

    (Array.isArray(items) ? items : []).forEach(item => {
        const li = document.createElement("li");
        li.textContent = String(item);
        list.appendChild(li);
    });
}


// =============================================
// BACKEND CONNECTION CHECK
// =============================================

async function checkBackend() {
    const status = document.getElementById("connectionStatus");

    try {
        const response = await fetch(API.health);

        if (!response.ok) {
            throw new Error("Backend unavailable");
        }

        if (status) {
            status.textContent = "Connected";
        }

    } catch (error) {

        if (status) {
            status.textContent = "Disconnected";
        }
    }
}


// =============================================
// ENGINEERING CONNECTION ASSESSMENT
// =============================================

const engineeringForm =
    document.getElementById("engineeringForm");

if (engineeringForm) {

    engineeringForm.addEventListener("submit", async event => {

        event.preventDefault();

        const button =
            engineeringForm.querySelector('button[type="submit"]');

        const error =
            document.getElementById("engineeringError");

        error.textContent = "";

        const feederId = getValue("engineeringFeeder");

        const requestedSolar =
            Number(getValue("requestedSolar"));

        if (
            !feederId ||
            !Number.isFinite(requestedSolar) ||
            requestedSolar <= 0
        ) {
            error.textContent =
                "Enter a valid feeder ID and solar capacity.";

            return;
        }

        button.disabled = true;
        button.textContent = "Assessing...";

        try {

            const data = await postJSON(
                API.connection,
                {
                    feeder_id: feederId,
                    requested_solar_kw: requestedSolar
                }
            );

            displayEngineeringResults(data);

        } catch (err) {

            error.textContent = err.message;

        } finally {

            button.disabled = false;
            button.textContent = "Assess Solar Connection";
        }
    });
}


// =============================================
// DISPLAY ENGINEERING RESULTS
// =============================================

function displayEngineeringResults(data) {

    const result = data.assessment || {};

    document
        .getElementById("engineeringResult")
        .classList.remove("hidden");

    setText(
        "engineeringStatus",
        (result.status || "Unavailable").replaceAll("_", " ")
    );

    setText(
        "engineeringMessage",
        result.message
    );

    setText(
        "existingSolar",
        `${showNumber(result.existing_solar_kw)} kW`
    );

    setText(
        "newSolar",
        `${showNumber(result.requested_new_solar_kw)} kW`
    );

    setText(
        "totalSolar",
        `${showNumber(result.proposed_total_solar_kw)} kW`
    );

    setText(
        "headroom",
        `${showNumber(result.demonstrated_additional_headroom_kw)} kW`
    );

    setText(
        "limitingFactor",
        result.first_limiting_factor
    );

    document
        .getElementById("engineeringResult")
        .scrollIntoView({
            behavior: "smooth",
            block: "start"
        });
}


// =============================================
// AI HOSTING CAPACITY ADVISORY
// =============================================

const aiForm = document.getElementById("aiForm");

if (aiForm) {

    aiForm.addEventListener("submit", async event => {

        event.preventDefault();

        const button =
            aiForm.querySelector('button[type="submit"]');

        const error =
            document.getElementById("aiError");

        error.textContent = "";

        const payload = {

            feeder_id: getValue("aiFeeder"),

            peak_load_kw:
                Number(getValue("peakLoad")),

            line_length_km:
                Number(getValue("aiLineLength")),

            existing_solar_kw:
                Number(getValue("existingSolarInput")),

            requested_solar_kw:
                Number(getValue("aiRequestedSolar"))
        };

        if (
            !payload.feeder_id ||
            !Number.isFinite(payload.peak_load_kw) ||
            payload.peak_load_kw <= 0 ||
            !Number.isFinite(payload.line_length_km) ||
            payload.line_length_km <= 0 ||
            !Number.isFinite(payload.existing_solar_kw) ||
            payload.existing_solar_kw < 0 ||
            !Number.isFinite(payload.requested_solar_kw) ||
            payload.requested_solar_kw <= 0
        ) {
            error.textContent =
                "Please enter valid feeder and solar details.";

            return;
        }

        button.disabled = true;
        button.textContent = "Running AI models...";

        try {

            const data = await postJSON(
                API.ai,
                payload
            );

            displayAIResults(
                data.ai_advisory || {}
            );

        } catch (err) {

            error.textContent = err.message;

        } finally {

            button.disabled = false;
            button.textContent = "Generate AI Advisory";
        }
    });
}


// =============================================
// DISPLAY AI RESULTS
// =============================================

function displayAIResults(result) {

    document
        .getElementById("aiResult")
        .classList.remove("hidden");

    setText(
        "aiStatus",
        (result.status || "Unavailable").replaceAll("_", " ")
    );

    setText(
        "aiMessage",
        result.explanation || "No explanation returned."
    );

    const regression =
        result.regression_prediction || {};

    const classification =
        result.classification_prediction || {};

    const inputs =
        result.inputs || {};

    setText(
        "predictedCapacity",
        `${showNumber(
            regression.estimated_additional_hosting_capacity_kw
        )} kW`
    );

    setText(
        "constraintClass",
        `Class ${classification.predicted_class ?? "Unavailable"}`
    );

    setText(
        "constraintScore",
        `${showNumber(
            classification.configured_violation_probability_percent
        )}%`
    );

    setText(
        "aiTotalSolar",
        `${showNumber(inputs.proposed_total_solar_kw)} kW`
    );

    fillList(
        "aiLimitations",
        result.limitations
    );

    document
        .getElementById("aiResult")
        .scrollIntoView({
            behavior: "smooth",
            block: "start"
        });
}


// =============================================
// PQ FEEDER CONFIGURATION PRESETS
// =============================================

const pqPresets = {

    FDR_SHORT: {
        length: 0.2,
        r1: 0.05,
        x1: 0.04
    },

    FDR_MEDIUM: {
        length: 0.5,
        r1: 0.05,
        x1: 0.04
    },

    FDR_LONG: {
        length: 1.0,
        r1: 0.05,
        x1: 0.04
    },

    FDR_HIGH_IMPEDANCE: {
        length: 2.0,
        r1: 0.10,
        x1: 0.08
    }
};

const pqFeeder =
    document.getElementById("pqFeeder");

if (pqFeeder) {

    pqFeeder.addEventListener("change", () => {

        const preset = pqPresets[pqFeeder.value];

        if (!preset) return;

        document.getElementById("pqLineLength").value =
            preset.length;

        document.getElementById("pqR1").value =
            preset.r1;

        document.getElementById("pqX1").value =
            preset.x1;
    });
}


// =============================================
// CREATE PQ METRIC CARD
// =============================================

function makeMetricCard(label, value) {

    const card = document.createElement("div");

    card.className = "result-item";

    const heading = document.createElement("p");

    heading.textContent = label;

    const valueElement = document.createElement("h3");

    valueElement.textContent = value;

    card.append(
        heading,
        valueElement
    );

    return card;
}


// =============================================
// LOAD SAVED PQ MODEL EVALUATION
// =============================================

async function loadPQModelInfo() {

    const loading =
        document.getElementById("pqModelLoading");

    const cards =
        document.getElementById("pqMetricCards");

    const feederContainer =
        document.getElementById("pqFeederValidation");

    const thresholdContainer =
        document.getElementById("pqThresholdAnalysis");

    if (!loading || !cards) return;

    try {

        const response = await fetch(API.pqInfo);

        const info = await response.json();

        if (!response.ok) {
            throw new Error(
                info.detail ||
                "Could not load PQ model information."
            );
        }

        const evaluation =
            info.evaluation || {};

        // PERFORMANCE CARDS

        cards.replaceChildren(

            makeMetricCard(
                "LOFO Accuracy",
                `${showNumber(evaluation.accuracy * 100)}%`
            ),

            makeMetricCard(
                "Balanced Accuracy",
                `${showNumber(evaluation.balanced_accuracy * 100)}%`
            ),

            makeMetricCard(
                "Class 1 Precision",
                `${showNumber(evaluation.class_1_precision * 100)}%`
            ),

            makeMetricCard(
                "Class 1 Recall",
                `${showNumber(evaluation.class_1_recall * 100)}%`
            ),

            makeMetricCard(
                "Class 1 F1",
                `${showNumber(evaluation.class_1_f1 * 100)}%`
            ),

            makeMetricCard(
                "Decision Threshold",
                showNumber(info.decision_threshold)
            )
        );

        loading.textContent =
            `Validation: ${info.validation_method || "Not reported"}. ` +
            "These are out-of-fold metrics on simulated configurations.";

        // FEEDER-WISE VALIDATION

        feederContainer.replaceChildren();

        const feederHeading =
            document.createElement("h3");

        feederHeading.textContent =
            "Feeder-wise validation";

        feederContainer.appendChild(feederHeading);

        const folds =
            Array.isArray(info.fold_results)
                ? info.fold_results
                : [];

        if (folds.length) {

            const table =
                document.createElement("table");

            const header =
                document.createElement("tr");

            [
                "Held-out Configuration",
                "Samples",
                "Accuracy",
                "Class 1 F1"
            ].forEach(label => {

                const th =
                    document.createElement("th");

                th.textContent = label;

                header.appendChild(th);
            });

            table.appendChild(header);

            folds.forEach(fold => {

                const row =
                    document.createElement("tr");

                [
                    fold.feeder,
                    fold.samples,
                    `${showNumber(fold.accuracy * 100)}%`,
                    showNumber(fold.class_1_f1)
                ].forEach(value => {

                    const cell =
                        document.createElement("td");

                    cell.textContent =
                        String(value ?? "Unavailable");

                    row.appendChild(cell);
                });

                table.appendChild(row);
            });

            feederContainer.appendChild(table);

        } else {

            const message =
                document.createElement("p");

            message.textContent =
                "No feeder-wise fold results are available.";

            feederContainer.appendChild(message);
        }

        // THRESHOLD ANALYSIS

        thresholdContainer.replaceChildren();

        const thresholdHeading =
            document.createElement("h3");

        thresholdHeading.textContent =
            "Exploratory threshold analysis";

        thresholdContainer.appendChild(thresholdHeading);

        const thresholds =
            Array.isArray(info.threshold_analysis)
                ? info.threshold_analysis
                : [];

        if (thresholds.length) {

            const table =
                document.createElement("table");

            const header =
                document.createElement("tr");

            [
                "Threshold",
                "Precision",
                "Recall",
                "F1",
                "False Negatives",
                "False Positives"
            ].forEach(label => {

                const th =
                    document.createElement("th");

                th.textContent = label;

                header.appendChild(th);
            });

            table.appendChild(header);

            thresholds.forEach(item => {

                const row =
                    document.createElement("tr");

                [
                    showNumber(item.threshold),

                    `${showNumber(item.precision * 100)}%`,

                    `${showNumber(item.recall * 100)}%`,

                    showNumber(item.f1),

                    item.false_negatives,

                    item.false_positives

                ].forEach(value => {

                    const cell =
                        document.createElement("td");

                    cell.textContent =
                        String(value ?? "Unavailable");

                    row.appendChild(cell);
                });

                table.appendChild(row);
            });

            thresholdContainer.appendChild(table);

        } else {

            const message =
                document.createElement("p");

            message.textContent =
                "No threshold comparison is available in the saved model.";

            thresholdContainer.appendChild(message);
        }

        // LIMITATIONS

        const limitations =
            Array.isArray(info.limitations)
                ? info.limitations
                : [];

        const note =
            document.getElementById("pqModelLimitations");

        if (note) {

            note.textContent =
                limitations.join(" ") ||
                "Model performance is based on simulated data and " +
                "requires independent engineering validation.";
        }

    } catch (error) {

        loading.textContent =
            `PQ model metrics unavailable: ${error.message}`;
    }
}


// =============================================
// PQ SCREENING FORM
// =============================================

const pqForm =
    document.getElementById("pqForm");

if (pqForm) {

    pqForm.addEventListener("submit", async event => {

        event.preventDefault();

        const button =
            pqForm.querySelector('button[type="submit"]');

        const error =
            document.getElementById("pqError");

        error.textContent = "";

        const payload = {

            feeder_id: getValue("pqFeeder"),

            line_length_km:
                Number(getValue("pqLineLength")),

            line_r1:
                Number(getValue("pqR1")),

            line_x1:
                Number(getValue("pqX1")),

            phase_a_load_kw:
                Number(getValue("pqPhaseA")),

            phase_b_load_kw:
                Number(getValue("pqPhaseB")),

            phase_c_load_kw:
                Number(getValue("pqPhaseC"))
        };

        if (
            !payload.feeder_id ||

            !Number.isFinite(payload.line_length_km) ||
            payload.line_length_km <= 0 ||

            !Number.isFinite(payload.line_r1) ||
            payload.line_r1 <= 0 ||

            !Number.isFinite(payload.line_x1) ||
            payload.line_x1 <= 0 ||

            !Number.isFinite(payload.phase_a_load_kw) ||
            payload.phase_a_load_kw < 0 ||

            !Number.isFinite(payload.phase_b_load_kw) ||
            payload.phase_b_load_kw < 0 ||

            !Number.isFinite(payload.phase_c_load_kw) ||
            payload.phase_c_load_kw < 0
        ) {

            error.textContent =
                "Enter valid line parameters and non-negative phase loads.";

            return;
        }

        button.disabled = true;

        button.textContent =
            "Running PQ screening...";

        try {

            const data = await postJSON(
                API.pq,
                payload
            );

            displayPQResults(data);

        } catch (err) {

            error.textContent = err.message;

        } finally {

            button.disabled = false;

            button.textContent =
                "Run PQ Screening";
        }
    });
}


// =============================================
// DISPLAY PQ SCREENING RESULTS
// =============================================

function displayPQResults(result) {

    document
        .getElementById("pqResult")
        .classList.remove("hidden");

    setText(
        "pqStatus",
        (result.screening_status || "Unavailable")
            .replaceAll("_", " ")
    );

    setText(
        "pqMessage",
        result.message
    );

    setText(
        "pqClass",
        `${result.predicted_class} — ${result.class_label || "Unknown"}`
    );

    setText(
        "pqScore",
        `${showNumber(result.class_1_model_score_percent)}%`
    );

    setText(
        "pqThreshold",
        `${showNumber(result.screening_threshold_percent)}% VUF`
    );

    setText(
        "pqValidation",
        result.validation_method || "Unavailable"
    );

    fillList(
        "pqLimitations",
        result.limitations
    );

    document
        .getElementById("pqResult")
        .scrollIntoView({
            behavior: "smooth",
            block: "start"
        });
}


// =============================================
// OPENDSS SIMULATION CHARTS
// =============================================

let voltageChartInstance = null;

let transformerChartInstance = null;

let lineChartInstance = null;


async function loadSimulationCharts() {

    const status =
        document.getElementById("chartStatus");

    if (!status) return;

    try {

        if (typeof Chart === "undefined") {

            throw new Error(
                "Chart.js did not load. Check your internet connection."
            );
        }

        const response =
            await fetch(API.hosting);

        const data =
            await response.json();

        if (!response.ok) {

            throw new Error(
                data.detail ||
                "Unable to load simulation results."
            );
        }

        const records =
            data.simulation_results || [];

        const validRecords = records.filter(row =>

            row.result === "PASS" &&

            row.minimum_voltage_pu !== "" &&

            row.maximum_voltage_pu !== "" &&

            row.transformer_loading_percent !== "" &&

            row.line_loading_percent !== ""
        );

        if (!validRecords.length) {

            throw new Error(
                "No valid passing simulation records are available."
            );
        }

        const sorted =
            validRecords.slice().sort(
                (a, b) =>
                    Number(a.solar_kw) -
                    Number(b.solar_kw)
            );

        const solar =
            sorted.map(row => Number(row.solar_kw));


        // COMMON CHART CREATOR

        function createChart(
            canvasId,
            existingInstance,
            datasets,
            yTitle
        ) {

            if (existingInstance) {
                existingInstance.destroy();
            }

            return new Chart(
                document.getElementById(canvasId),
                {
                    type: "line",

                    data: {
                        labels: solar,
                        datasets: datasets
                    },

                    options: {
                        responsive: true,
                        maintainAspectRatio: true,

                        scales: {

                            x: {
                                title: {
                                    display: true,
                                    text: "Solar Generation (kW)"
                                }
                            },

                            y: {
                                title: {
                                    display: true,
                                    text: yTitle
                                }
                            }
                        }
                    }
                }
            );
        }


        // VOLTAGE CHART

        voltageChartInstance = createChart(
            "voltageChart",
            voltageChartInstance,
            [
                {
                    label: "Minimum Voltage (pu)",

                    data: sorted.map(
                        row => Number(row.minimum_voltage_pu)
                    ),

                    borderColor: "#34d399",
                    tension: 0.3
                },

                {
                    label: "Maximum Voltage (pu)",

                    data: sorted.map(
                        row => Number(row.maximum_voltage_pu)
                    ),

                    borderColor: "#60a5fa",
                    tension: 0.3
                }
            ],
            "Voltage (pu)"
        );


        // TRANSFORMER CHART

        transformerChartInstance = createChart(
            "transformerChart",
            transformerChartInstance,
            [
                {
                    label: "Transformer Loading (%)",

                    data: sorted.map(
                        row => Number(row.transformer_loading_percent)
                    ),

                    borderColor: "#a78bfa",
                    tension: 0.3
                }
            ],
            "Loading (%)"
        );


        // LINE LOADING CHART

        lineChartInstance = createChart(
            "lineChart",
            lineChartInstance,
            [
                {
                    label: "Distribution Line Loading (%)",

                    data: sorted.map(
                        row => Number(row.line_loading_percent)
                    ),

                    borderColor: "#f59e0b",
                    tension: 0.3
                }
            ],
            "Loading (%)"
        );


        status.textContent =
            `Loaded ${validRecords.length} passing simulation records.`;

    } catch (error) {

        status.textContent = error.message;

        console.error(error);
    }
}


// =============================================
// INITIALIZE DASHBOARD
// =============================================

async function initializeDashboard() {

    await checkBackend();

    await loadPQModelInfo();

    await loadSimulationCharts();
}

initializeDashboard();



// =============================================
// SUBTLE POINTER DETAIL (desktop only)
// =============================================
(function initPointerDetail() {
    if (window.matchMedia("(pointer: fine)").matches) {
        const pointer = document.createElement("span");
        pointer.className = "gs-pointer";
        pointer.setAttribute("aria-hidden", "true");
        document.body.appendChild(pointer);

        let pointerX = -100, pointerY = -100;
        window.addEventListener("pointermove", (event) => {
            pointerX = event.clientX;
            pointerY = event.clientY;
            pointer.style.transform = `translate3d(${pointerX}px, ${pointerY}px, 0)`;
            pointer.classList.add("is-visible");
        }, { passive: true });

        document.addEventListener("pointerover", (event) => {
            if (event.target.closest("a, button, input, select, textarea, label")) {
                pointer.classList.add("is-interactive");
            } else {
                pointer.classList.remove("is-interactive");
            }
        }, { passive: true });
    }
})();
